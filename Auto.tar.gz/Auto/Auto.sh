#!/bin/bash
#Script Develop for Ing.Kenny Ortiz

#make the menu.xml
cat << EOF > menu.xml 
<?xml version="1.0" encoding="UTF-8"?>
<module>
<menulist>
<menuitem parent="" module="no" link="" menuid="Generator" desc="Generator" order="23" />
<menuitem parent="Generator" module="yes" link="" menuid="Auto" desc="Auto_Generator" order="1"/>
</menulist>
</module>
EOF

issabel-menumerge ./menu.xml
rm -f ./menu.xml

#Copy  all modules to /var/www/html/modules/ de isabell
cp -r ./Modulos/* /var/www/html/modules/







































